document.getElementById('summarizeButton').addEventListener('click', async function() {
    const inputText = document.getElementById('inputText').value;
    const summaryOutput = document.getElementById('summaryOutput');

    const summarizeText = async (text) => {
        const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=GEMINI_API_KEY', { // Replace with the actual API endpoint
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer AIzaSyDHWe32EdCxduAUOvl4CAopedd3nvE3GAA' // Your API key
            },
            body: JSON.stringify({ text: text }) // Adjust based on the API's expected input
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        return data.summary; // Adjust based on the API's response structure
    };

    if (inputText.trim() === '') {
        summaryOutput.innerHTML = 'Please enter some text to summarize.';
    } else {
        try {
            const summary = await summarizeText(inputText);
            summaryOutput.innerHTML = summary;
        } catch (error) {
            summaryOutput.innerHTML = 'Error summarizing text: ' + error.message;
        }
    }
});