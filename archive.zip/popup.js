let highlightedText = ""; // Variable to store highlighted text

// Event listener for the highlight button
document.getElementById('highlight').addEventListener('click', () => {
    const keyword = document.getElementById('keyword').value;
    if (keyword) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, { keyword: keyword }, (response) => {
                if (response && response.highlightedText) {
                    highlightedText = response.highlightedText; // Store highlighted text
                }
            });
        });
    }
});

// Open a new tab with the highlighted text, show button with integrated textbox, and summarize button
document.getElementById('open').addEventListener('click', () => {
    if (highlightedText) {
        const newTab = window.open();
        newTab.document.write(`
            <html>
                <head>
                    <title>Highlighted Text</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            margin: 20px;
                        }
                        h1 {
                            font-size: 24px;
                            color: #333;
                        }
                        .highlighted {
                            background-color: yellow;
                            padding: 2px;
                            border-radius: 3px;
                        }
                        #hiddenText {
                            display: none;
                            margin-top: 10px;
                        }
                        button {
                            padding: 5px 10px;
                            margin: 5px 0;
                            cursor: pointer;
                            background-color: #4CAF50;
                            color: white;
                            border: none;
                            border-radius: 3px;
                        }
                        button:hover {
                            background-color: #45a049;
                        }
                        textarea {
                            width: 100%;
                            padding: 5px;
                            margin: 10px 0;
                            border: 1px solid #ccc;
                            box-sizing: border-box;
                        }
                        #summaryResult {
                            margin-top: 10px;
                            font-weight: bold;
                            color: #333;
                        }
                    </style>
                </head>
                <body>
                    <h1>Highlighted Sentences</h1>
                    <button id="showButton">show</button>
                    <div id="hiddenText">
                        ${highlightedText.replace(/<br>/g, '<br>')}
                        <br>
                        <textarea id="textToSummarize" placeholder="Enter text to summarize..." rows="4" cols="50"></textarea>
                        <br>
                        <button id="summarizeButton">Summarize</button>
                    </div>
                    <div id="summaryResult"></div>
                    <script src="newTabScript.js"></script>
                </body>
            </html>
        `);
        newTab.document.close();
    } else {
        alert("Please highlight some text first.");
    }
});

// Optional: Add functionality for the SUMM. button if needed
document.getElementById('summ').addEventListener('click', () => {
    alert("This button can be used for additional summarization features.");
});