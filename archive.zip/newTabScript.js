// Toggle visibility of highlighted text and textbox
document.getElementById('showButton').addEventListener('click', () => {
    const hiddenText = document.getElementById('hiddenText');
    if (hiddenText.style.display === 'none') {
        hiddenText.style.display = 'block';
    } else {
        hiddenText.style.display = 'none';
    }
});

// Function to summarize text
function summarizeText(text) {
    return text.length > 100 ? text.substring(0, 100) + '...' : text;
}

// Event listener for the summarize button
document.getElementById('summarizeButton').addEventListener('click', () => {
    const textToSummarize = document.getElementById('textToSummarize').value;
    if (textToSummarize) {
        const summarizedText = summarizeText(textToSummarize);
        document.getElementById('summaryResult').innerText = 'Summarized Text: ' + summarizedText;
    } else {
        alert("Please enter some text to summarize.");
    }
});